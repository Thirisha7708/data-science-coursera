NEI <- readRDS("summarySCC_PM25.rds")

balt <- subset(NEI, fips == "24510")
motor <- subset(balt, type == "ON-ROAD")

total_motor <- aggregate(Emissions ~ year, motor, sum)

png("plot5.png")

plot(total_motor$year, total_motor$Emissions, type = "b",
     xlab = "Year",
     ylab = "Motor Vehicle Emissions",
     main = "Baltimore Motor Vehicle Emissions")

dev.off()