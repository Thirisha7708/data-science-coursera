NEI <- readRDS("summarySCC_PM25.rds")

balt <- subset(NEI, fips == "24510")
total_balt <- aggregate(Emissions ~ year, balt, sum)

png("plot2.png")

plot(total_balt$year, total_balt$Emissions, type = "b",
     xlab = "Year",
     ylab = "Total Emissions",
     main = "Baltimore PM2.5 Emissions")

dev.off()