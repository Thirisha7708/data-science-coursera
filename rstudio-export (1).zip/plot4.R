NEI <- readRDS("summarySCC_PM25.rds")
SCC <- readRDS("Source_Classification_Code.rds")

coal <- grepl("coal", SCC$EI.Sector, ignore.case = TRUE)
coal_scc <- SCC[coal, "SCC"]

coal_data <- NEI[NEI$SCC %in% coal_scc, ]

total_coal <- aggregate(Emissions ~ year, coal_data, sum)

png("plot4.png")

plot(total_coal$year, total_coal$Emissions, type = "b",
     xlab = "Year",
     ylab = "Coal Emissions",
     main = "Coal-related PM2.5 Emissions")

dev.off()