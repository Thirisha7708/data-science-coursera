NEI <- readRDS("summarySCC_PM25.rds")

motor <- subset(NEI, type == "ON-ROAD")

compare <- subset(motor, fips %in% c("24510", "06037"))

total_compare <- aggregate(Emissions ~ year + fips, compare, sum)

png("plot6.png")

library(ggplot2)

ggplot(total_compare, aes(x = year, y = Emissions, color = fips)) +
  geom_line() +
  geom_point() +
  ggtitle("Motor Vehicle Emissions: Baltimore vs LA")

dev.off()