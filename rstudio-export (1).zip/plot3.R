library(ggplot2)

NEI <- readRDS("summarySCC_PM25.rds")
balt <- subset(NEI, fips == "24510")

png("plot3.png")

ggplot(balt, aes(x = factor(year), y = Emissions)) +
  geom_bar(stat = "summary", fun = "sum") +
  facet_wrap(~type) +
  xlab("Year") +
  ylab("Emissions") +
  ggtitle("Baltimore Emissions by Source Type")

dev.off()